// DEFAULT BASE ILMANHDYT
// POWERED BY KRIZYN OFC
// JANGAN DIHAPUS KALAU MAU DITAMBAHIN

// NUMBER
global.owner = ['62895327934887'] 
global.mods = [] 
global.prems = [] 
global.kontak = ['62895327934887']

//  INFO BOT 
global.naown = 'KRIZYN OFC'
global.noown = '62895327934887'
global.namebot = 'FORYN FOUR'
global.nobot = '6289502319715'

//  URL SOSMED
global.instagram = 'https://instagram.com/itskri99'
global.github = 'https://github.com/krizynofc'
global.gc = 'https://chat.whatsapp.com/HVyRaNWp18NKMAIHv8NjLP'
global.web = 'https://lynk.id/kri.com' //ubah jadi website lu, bisa link ig, link github, link yt, klo link gc ntr beda tampilan lagi. 
global.saweria = 'https://saweria.co/Kricom'

// PAYMANT 
global.dana = '081360482998'
global.pulsa = '081360482998'
global.gopay = '081360482998'
global.shopay = '081360482998'
global.ovo = '081360482998'

// PROFILE ALL 
global.ppreg = 'https://telegra.ph/file/445721f7cdab701543840.jpg'
global.fotonya1 = 'https://telegra.ph/file/c58f43806ef4b7038a7f4.jpg' //ganti jadi foto bot mu
global.fotonya2 = 'https://telegra.ph/file/c58f43806ef4b7038a7f4.jpg' //ini juga ganti 
global.ppacc = 'https://telegra.ph/file/a077271ff372545599dbc.jpg'
global.imgloc = 'https://telegra.ph/file/e6355ade20840c96814ed.jpg'
global.media = 'https://telegra.ph/file/f209153a54698c43032f7.jpg'
global.ppm = 'https://telegra.ph/file/85f5dd4cfb4fdd9d65cbf.jpg'  // bagian atas all command

global.fla = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=smurfs-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='

// TYPE DOCUMENT 
global.dpptx = 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
global.ddocx = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
global.dxlsx = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
global.dpdf = 'application/pdf'
global.drtf = 'text/rtf'
global.djson = 'application/json'

global.thumbdoc = 'https://telegra.ph/file/6e45318d7c76f57e4a8bd.jpg'

// FAKE SIZE
global.fsizedoc = '99999999999999' // default 10TB
global.fpagedoc = '999'

// WATERMARK  
global.wm = 'ᬊᬁ 𝐅𝐎𝐑𝐘𝐍 𝐅𝐎𝐔𝐑'
global.watermark = wm
global.wm2 = '⫹⫺ 𝙋𝙤𝙬𝙚𝙧𝙚𝙙 𝘽𝙮 𝙆𝙧𝙞𝙯𝙮𝙣𝙊𝙛𝙘'
global.wm3 = '⫹⫺ 𝐅𝐎𝐑𝐘𝐍 𝐅𝐎𝐔𝐑 | BOT WHATSAPP MD'
global.tb = 'WHATSAPP BOT MULTI DEVICE'

//  DEFAULT MENU  
global.dbki = '╭──〔'
global.dbka = '〕─⬣'
global.kime = '┃⳹'
global.ki = '┃'
global.dbki2 = '┃──〔'
global.dbka2 = '〕─⬣'
global.dba = '╰─────────────⬣'

// HIASAN COMMAND 
global.bhki = '┏═┅〔'
global.bhka = '〕┅═✦\n┃'
global.bdy = '┃⫹⫺'
global.ftb = '┃\n┗━━══┅┅══━━━✦\n'

global.admen = `┏═┅〔 *SUPPORT* 〕┅═✦
┃
┃⫹⫺ Nurutomo
┃⫹⫺ Ilmanhdyt
┃⫹⫺ Elyas
┃⫹⫺ Hyzer
┃⫹⫺ KrizynOfc
┃⫹⫺ Zivsan
┃⫹⫺ Mursid
┃⫹⫺ Jarot
┃⫹⫺ Kanna
┃⫹⫺ Fokusid
┃
┗━━══┅┅══━━━✦`
        
// HIASAN MENU LAINNYA 
global.hki = '––––––『' 
global.hka = '』––––––'


// INFO BOT
global.wait = '⏳ Tunggu Sedang Proses...'
global.eror = '_*🤦 Server Bot tidak ditemukan*_'

global.benar = 'Benar ✅\n'
global.salah = 'Salah ❌\n'

// WATERMARK STICKER 
global.stiker_wait = '⏳ Stiker sedang Proses'
global.packname = 'FORYN FOUR'
global.author = 'By krizynOfc'

//  APIKEY ANDA 
global.lolkey = 'Papah-Chan' //biar mudah ngegantinya semisal apikeynya expired:v
global.zenzkey = 'BagasPrdn' //ganti jadi apikey lu kalau expired

// APIKEY  
global.APIs = { // API Prefix
  // name: 'https://website'
  amel: 'https://melcanz.com',
    bx: 'https://bx-hunter.herokuapp.com',
  dhnjing: 'https://dhnjing.xyz',
  hardianto: 'https://hardianto-chan.herokuapp.com',
  jonaz: 'https://jonaz-api-v2.herokuapp.com',
  neoxr: 'https://neoxr-api.herokuapp.com',
  nrtm: 'https://nurutomo.herokuapp.com',
  xteam: 'https://api.xteam.xyz',
  nzcha: 'http://nzcha-apii.herokuapp.com',
  bg: 'http://bochil.ddns.net',
  fdci: 'https://api.fdci.se',
  dzx: 'https://api.dhamzxploit.my.id',
  bsbt: 'https://bsbt-api-rest.herokuapp.com',
  zahir: 'https://zahirr-web.herokuapp.com',
  zeks: 'https://api.zeks.xyz',
  zekais: 'http://zekais-api.herokuapp.com',
  pencarikode: 'https://pencarikode.xyz', 
  erdwepe: 'https://erdwpe-api.herokuapp.com',
  lolhuman: 'https://api.lolhuman.xyz',
  LeysCoder: 'https://leyscoders-api.herokuapp.com',
  rey: 'https://server-api-rey.herokuapp.com'
}
global.APIKeys = { // APIKey Here
  // 'https://website': 'apikey'
  'https://melcanz.com': 'elaina',
  'https://server-api-rey.herokuapp.com': 'apirey',
  'https://api.xteam.xyz': 'd37372311698ed1d',
  'https://zahirr-web.herokuapp.com': 'zahirgans',
  'https://bsbt-api-rest.herokuapp.com': 'benniismael',
  'https://api.zeks.xyz': 'apivinz',
  'https://hardianto-chan.herokuapp.com': 'hardianto',
  'https://pencarikode.xyz': 'pais', 
  'https://leyscoders-api.herokuapp.com': 'dappakntlll',
  'https://zekais-api.herokuapp.com': 'apikeymu',
  'https://api.lolhuman.xyz': 'Deffbotz',
}

// LEVEL UP 
global.multiplier = 69 // The higher, The harder levelup

// RPG GAMES 
global.rpg = {
  emoticon(string) {
    string = string.toLowerCase()
    let emot = {
      exp: '✉️',
      money: '💵',
      potion: '🥤',
      diamond: '💎',
      common: '📦',
      uncommon: '🎁',
      mythic: '🗳️',
      legendary: '🗃️',
      pet: '🎁',
      sampah: '🗑',
      armor: '🥼',
      sword: '⚔️',
      kayu: '🪵',
      batu: '🪨',
      string: '🕸️',
      kuda: '🐎',
      kucing: '🐈' ,
      anjing: '🐕',
      petFood: '🍖',
      gold: '👑',
      emerald: '💚'
    }
    let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
    if (!results.length) return ''
    else return emot[results[0][0]]
  }
}

//===========『 PEMBATAS JANGAN DI UBAH 』================ //

let fs = require('fs')
let chalk = require('chalk')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  delete require.cache[file]
  require(file)
})
